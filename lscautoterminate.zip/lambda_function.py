import json
import random
import os
    
import datetime 
import time
import boto3
import dateutil.parser



from boto3.dynamodb.conditions import Key, Attr

client      = boto3.client('servicecatalog')
dy_client   = boto3.client('dynamodb')
aws_acct_id = boto3.client('sts').get_caller_identity()['Account'] 
dynamodb = boto3.resource('dynamodb')


table_name  = 'sc-autoterminate-%s' %  aws_acct_id
#

def check_for_ses_email(event):
    awsregion =   os.environ['AWS_REGION']

    client =   boto3.client('ses',region_name=awsregion)
    emails =   client.list_verified_email_addresses()

    #print(emails)
    if event['etoemail'] in emails['VerifiedEmailAddresses']:
        print('Found ' +  event['etoemail'] )
        _ret = True
    else:
        response = client.verify_email_identity(EmailAddress= event['etoemail'])
        print('Email address not Found ' +  event['etoemail'] +" Verification sent")
        _ret = False
    return _ret
    
def sendemail(event):
    sender    = event['etoemail']
    recipient = event['etoemail']
    #awsregion = "us-east-1"
    awsregion =   os.environ['AWS_REGION']

    charset = "UTF-8"
    client = boto3.client('ses',region_name=awsregion)
    try:
        #Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    event['etoemail'],
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': charset,
                        'Data': event['ebody'],
                    },
                    'Text': {
                        'Charset': charset,
                        'Data': event['ebody'],
                    },
                },
                'Subject': {
                    'Charset': charset,
                    'Data': event['esubject'],
                },
            },
            Source=event['etoemail'],
        )
    except Exception as e:
      return(  e) 
    else:
      return('EmailSent to ' + event['etoemail'])
      
def termprov(ProvisionedProductId):
    _rand =  int(random.random()*10000000)
    tok = 'ktokw%s'% _rand 
    _ret = client.terminate_provisioned_product(AcceptLanguage='en',ProvisionedProductId=ProvisionedProductId,TerminateToken=tok,IgnoreErrors=False)
    return _ret

def terminate_sc_products(tevent):
    l=1
    #return tevent
    for _t in tevent['Items']:
        if _t['action'] == 'Terminate':
            if 'Terminated' in _t:
                m = 'already terminated'
            else :
                mevent={}
                termprov(_t['ProvisionedProductId'])
                mevent['etoemail'] = _t['owner']
                mevent['esubject'] = "AWS Service Catalog Auto terminate feature has terminated the [ %s ] AWS Service Catalog Product " % _t['provisionedProductName']
                mevent['ebody'] = mevent['esubject']
                print(mevent['esubject'])
                if check_for_ses_email(mevent)  == True:
                   print( sendemail(mevent) )
                updateATtable(_t['ProvisionedProductId'],'Terminated')
        if _t['action'] == 'Notify':        
            if 'Notified' in _t:
                m = 'already Nofified'
            else :
                mevent={}
                #termprov(_t['ProvisionedProductId'])
                mevent['etoemail'] = _t['owner']
                mevent['esubject'] = "AWS Service Catalog Auto terminate feature is notifying you that  Service Catalog product [ %s ] has an action of Notify and has reached its end time. It is still incurring cost." % _t['provisionedProductName']
                mevent['ebody'] = mevent['esubject']
                print(mevent['esubject'])
                if check_for_ses_email(mevent)  == True:
                   print( sendemail(mevent) )
                updateATtable(_t['ProvisionedProductId'],'Notified')
        
    
def updateATtable(ProvisionedProductId,_action)    :
    search_key  = {"ProvisionedProductId":ProvisionedProductId}
    tsresults = f_getmasterdbinfo(table_name,search_key) 
    if 'Item' in tsresults:
        print('found')
        if _action in tsresults:
            print('Already ' + _action)
        else:
            format = "%a %b %d %H:%M %Y"
            _now     = datetime.datetime.now()
            termtime = _now.strftime(format) 
            key              = {"ProvisionedProductId": {"S": ProvisionedProductId}}
            AttributeUpdates = {_action+"DateTime":{"Value":{"S": termtime }},_action:{"Value":{"S": "Yes" }} } 
            b = master_tb_adjust(table_name,key,AttributeUpdates)
    else:
         print('not found')
    return 'ok'

  
def jtoli(j):
    _ret =''
    for ll in j:
        _ret += "<li>%s=%s</li>" % (ll,j[ll])
    return(_ret)
    
def check_end_time(event):
    d =   datetime.datetime.now() 
    _ret={}
    dynamodb = boto3.resource('dynamodb')
    
    #pass termination date
    table = dynamodb.Table(table_name)
    response = table.scan(
        FilterExpression=Attr('terminateDate').lt( str(d) )
    )
 
    _ret['Items'] = response['Items']
    for _d in response['Items']:
        if _d['action'] == 'Terminate':
            mail={}
            mail['etoemail']=_d['owner']
            mail['ebody'] = _d['provisionedProductName'] +' has expired'
            mail['esubject'] = _d['provisionedProductName'] +' has expired' 
            #print(sendemail(mail))

    return(_ret)
    
def chk_ex_in_time(dd,hh,mm):
                
    #pass in 1 day 
    d =   datetime.datetime.now() 
    _ret ={}
    tomorrow =  d   + datetime.timedelta(days=dd,hours=hh,minutes=mm)
    table = dynamodb.Table(table_name)
    ttresponse = table.scan(
        FilterExpression=Attr('terminateDate').between( str(d) , str(tomorrow) )  
     
     )
    _ret = {'Items':ttresponse['Items'] }
     

    return _ret
  

def f_getmasterdbinfo(table_name,jitem):
   
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)
    d_res = table.get_item(Key=jitem)
    _ret = d_res 
    return _ret
    
def master_tb_adjust(table_name,key,AttributeUpdates):
    p_req = dy_client.update_item(TableName=table_name,Key=key,AttributeUpdates=AttributeUpdates)
    return(p_req)    
    

def store_sc_to_db(event):
    
    format = "%a %b %d %H:%M %Y"
    _now     = datetime.datetime.now()
    startTime = _now.strftime(format) 
    _endtime = _now + datetime.timedelta(days=int(event['days']),hours=int(event['hours']),minutes=int(event['minutes']))
    _endtime_display =  _endtime.strftime(format) 
    pp='pp-%s' %  int(random.random()*10000000)
    _item = '{"ProvisionedProductId": {"S": "%s"},"terminateDate": {"S": "%s"},"owner":{"S":"%s"},"provisionedProductName":{"S":"%s"},"productId":{"S":"%s"},"action":{"S":"%s"},"EndTime": {"S": "%s"},"StartTime": {"S": "%s"} }'  % (event['ProvisionedProductId'], _endtime,event['ContactEmail'],event['provisionedProductName'],event['productId'],event['action'],_endtime_display,startTime)
    _jitem=json.loads(_item)
    p_req= dy_client.put_item(TableName=table_name,Item = _jitem )
    return

def get_DB_info(event):
    devent={}
    
    devent['ProvisionedProductId']  = event['detail']['responseElements']['recordDetail']['provisionedProductId']
    devent['provisionedProductName']= event['detail']['responseElements']['recordDetail']['provisionedProductName']
    devent['productId']= event['detail']['responseElements']['recordDetail']['productId']
    devent['start_time']=event['time'] 
    for _p in event['detail']['requestParameters']['provisioningParameters']:
            if _p['key'] == 'Action':  
                devent['action'] = _p['value']
            if _p['key'] == 'DurationMinutes':  
                devent['minutes'] = _p['value']
            if _p['key'] == 'ContactEmail':  
                devent['ContactEmail'] = _p['value']
            if _p['key'] == 'DurationHours':  
                devent['hours'] = _p['value']
            if _p['key'] == 'DurationDays':  
                devent['days'] = _p['value']
    store_sc_to_db(devent)
    ####
    format = "%a %b %d %H:%M %Y"
    _now     = datetime.datetime.now()
    startTime = _now.strftime(format) 
    _endtime = _now + datetime.timedelta(days=int(devent['days']),hours=int(devent['hours']),minutes=int(devent['minutes']))
    _endtime_display =  _endtime.strftime(format) 
    
    mevent={}
    mevent['etoemail'] = devent['ContactEmail'] 
    mevent['esubject'] = "AWS Service Catalog product [ %s ] deployed with auto termination configuration." % devent['provisionedProductName']
    mevent['ebody'] = 'Hello,<br><hr>%s The end time is <b>%s</b> with an terination action of <b>%s</b> ' % (mevent['esubject'], _endtime_display,devent['action'] )
    if check_for_ses_email(mevent)  == True:
        print( sendemail(mevent) )
    ######            
    return(devent)
    
def lambda_handler(event, context):
    print(event)

    _ret =''
    if event['source']=="aws.servicecatalog":
        if event['detail']['eventName'] ==  "ProvisionProduct":
            for _p in event['detail']['requestParameters']['provisioningParameters']:
                if _p['key'] == 'AutoTerminate':
                    if _p['value'] == 'True':
                        print('This is an autoterminate product')
                        _ret= get_DB_info(event)
        if event['detail']['eventName'] ==  "TerminateProvisionedProduct":
            updateATtable(event['detail']['responseElements']['recordDetail']['provisionedProductId'],'Terminated')
            f='f'
    if event['source']=="aws.events":
        _passTermination     = check_end_time(event) 
        _terminatingTomorrow = chk_ex_in_time(1,7,0)
        print( _terminatingTomorrow  )
        _ret={"Tnow":_passTermination,"TerminatinInADay":_terminatingTomorrow }
        _ret = terminate_sc_products(_passTermination)
        
    return _ret    